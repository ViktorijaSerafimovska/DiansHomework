import React, { useState } from 'react';
import './RegisterForm.css';
import logo from '../../assets/logo.png';

const RegisterForm: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState<string | null>(null);

    const handleRegister = async (event: React.FormEvent) => {
        event.preventDefault();
        setError(null);

        if (password !== confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        try {
            const response = await fetch('/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                throw new Error('Failed to register');
            }

            alert('Registration successful!');
        } catch (err: any) {
            setError(err.message);
        }
    };

    return (
        <>
            <div className="header">
                <img src={logo} alt="StockEdge MK Logo" />
            </div>
            <div className="register-container">
                <div className="register-box">
                    <h1>Register</h1>
                    <form onSubmit={handleRegister} className="register-form">
                        <label htmlFor="email">User name / email</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        <label htmlFor="confirmPassword">Confirm password</label>
                        <input
                            type="password"
                            id="confirmPassword"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                        />
                        {error && <p className="error">{error}</p>}
                        <button type="submit" className="register-button">Register</button>
                    </form>
                </div>
            </div>
        </>
    );
};

export default RegisterForm;





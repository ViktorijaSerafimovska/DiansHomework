import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './LoginForm.css';
import logo from '../../assets/logo.png';

const LoginForm: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);

    const handleLogin = async (event: React.FormEvent) => {
        event.preventDefault();
        setError(null);

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                throw new Error('Invalid email or password');
            }

            const data = await response.json();
            alert(`Login successful! Token: ${data.token}`);
        } catch (err: any) {
            setError(err.message);
        }
    };

    return (
        <>
            <div className="header">
                <img src={logo} alt="StockEdge MK Logo" />
            </div>
            <div className="login-container">
                <div className="login-box">
                    <h1>Login</h1>
                    <p>Sign in to continue</p>
                    <form onSubmit={handleLogin} className="login-form">
                        <label htmlFor="email">EMAIL</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                        <label htmlFor="password">PASSWORD</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        {error && <p className="error">{error}</p>}
                        <div className="login-links">
                            <Link to="/register" className="register-link">Don't have an account?</Link>
                            <Link to="/forgot-password" className="forgot-password-link">Forgot password?</Link>
                        </div>
                        <button type="submit" className="login-button">Log In</button>
                    </form>
                </div>
            </div>
        </>
    );
};

export default LoginForm;

